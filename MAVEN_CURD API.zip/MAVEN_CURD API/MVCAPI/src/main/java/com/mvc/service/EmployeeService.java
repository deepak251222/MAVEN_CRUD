package com.mvc.service;



import com.mvc.dto.Employee;
public interface EmployeeService {
    public String addEmployee(Employee emp);
    public Employee searchEmployee(String eid);
    public String deleteEmployee(String eid);
    public String updateEmployee(Employee emp);
    
}
