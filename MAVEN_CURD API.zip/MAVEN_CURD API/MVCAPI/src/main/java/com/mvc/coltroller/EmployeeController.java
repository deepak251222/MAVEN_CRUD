package com.mvc.coltroller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.stereotype.Controller;

import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mvc.dto.Employee;
import com.mvc.service.EmployeeService;
import com.mvc.service.EmployeeServiceImpl;

@Controller

public class EmployeeController {
	
	
	@Autowired(required=true)
	private EmployeeService employeeService;

	String status="";
	String message="";
	
	@RequestMapping("/home")
	public String home()
	{
		return "home";
	}
	
	
	//***---------- ADD CONTROLLER---------*** 
	
	@RequestMapping("/addpage")
	public String addpage()
	{
		return "addform";
	}
	
	@RequestMapping(path="/add",method = RequestMethod.POST)
   public ModelAndView add(@Valid @ModelAttribute ("employee") Employee employee,BindingResult errors)
	
	{
	
		ModelAndView mav=null;
		if(errors.hasErrors())
		{
			//System.out.println(errors);
			System.out.println("Binding : " +errors);
			return new ModelAndView("addform","employee",employee);
		}
	
	     status=(String) employeeService.addEmployee(employee);
        
	 
	   if(status.equals("success"))
	   {
		   message="Insert is SuccessFull";
	   }
	   if(status.equals("failure"))
	   {
		   message="Insert is Faluire";
	   }
	   if(status.equals("existed"))
	   {
		   message="Already Existed";
	   }
		 mav =new ModelAndView("status", "message", message);
	//	mav=new ModelAndView("status","message",message);
	
		return mav;
	}
	
	
	//**----------SEARCH CONTROLLER ---------**
	
	
	@RequestMapping("/searchpage")
	public String serachpage()
	{
		return "searchform";
	}
	@RequestMapping(path = "/search",method = RequestMethod.POST)
	public ModelAndView search(Employee employee)
	{
		ModelAndView mav=null;
		Employee emp=employeeService.searchEmployee(employee.getEid());
		if(emp==null)
		{
			message="Don't Exist";
			mav=new ModelAndView("status","message",message);
			
		}else {
			//System.out.println( " Search Form :" + emp.getEid() + emp.getEname() + emp.getEe());
	       mav=new ModelAndView("employee","employee",emp);
		}
	   return mav;	
	}

	//**------------UPDATE CONTROLLER -----------**
	
	@RequestMapping("/updatepage")
	public String updateform()
	{
		return "updateform";
	}
	@RequestMapping(value="/editform",method = RequestMethod.POST)
	public ModelAndView editform(Employee emp)
	{
		ModelAndView mav=null;
		Employee employee=employeeService.searchEmployee(emp.getEid());
		if(employee==null)
		{
			message="Don't Exist";
			mav=new ModelAndView("status","message",message);
		}else {
			mav=new ModelAndView("employee_edit_form","emp",employee);
		}
		
		return mav;
		
	}
	
	@RequestMapping(value="/update",method = RequestMethod.POST)
	public ModelAndView update(@ModelAttribute Employee employee)
	{
		ModelAndView mav=null;
		
		
		  status=(String) employeeService.updateEmployee(employee);

		 
		   if(status.equals("success"))
		   {
			   message="Update is sucessFull";
		   }
		   if(status.equals("failure"))
		   {
			   message="Insert is Faluire";
		   }
		   if(status.equals("existed"))
		   {
			   message="Already Existed";
		   }
			
		 mav =new ModelAndView("status", "message", message);
		  
		
		return mav;
		
	}
	 
	//***------------DELETE CONTROLLER----------***
	
	@RequestMapping("/deletepage")
	public String deletepage()
	{
		return "deleteform";
	}
	@RequestMapping(path="/delete",method = RequestMethod.POST)
	public ModelAndView delete(Employee employee)
	{
		ModelAndView mav=null;
	     String find=employeeService.deleteEmployee(employee.getEid());
	     if(find=="success") {
	    	 message="Delete SuccessFull";
	      mav=new ModelAndView("status1","message",message);
	     }else {
	    	 message="Employee Don't Exist";
	     mav=new ModelAndView("status1","message",message);
	     }
	     
	     
		return mav;
	}
	
}
