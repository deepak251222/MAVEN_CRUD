package com.mvc.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mvc.dto.Employee;

@Repository("employeeDao")

public class EmployeeDaoImp implements EmployeeDao {
 
    String status="";
	@Autowired
	private HibernateTemplate hibernateTemplate;

//	public void setHibernateTemplate(HibernateTemplate hibernateTemplate)
//	{
//		this.hibernateTemplate=hibernateTemplate;
//	}
	@Transactional
	@Override
	
	public String add(Employee emp) {
		// TODO Auto-generated method stub
		try {
			 
			Employee empdata=hibernateTemplate.get(Employee.class,emp.getEid());
			 if(empdata==null)
			 {
				String empid=(String)hibernateTemplate.save(emp);
				if(empid.equals(emp.getEid()))
				{
					status="success";
					
				}
				else
				{
					status="failure";
				}
			 }else
			 {
				 status="existed";
			 }
			
		}catch (Exception e) {
			e.printStackTrace();
			status="failure";
		}
		return status;
	}
  
	
	
	@Override
	public Employee search(String eid) {
		Employee emp=null;
		try {
	      emp=hibernateTemplate.get(Employee.class, eid);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return emp;
	}

	@Override
	public String delete(String eid) {
		try {
			Employee emp=hibernateTemplate.get(Employee.class, eid);
			if(emp==null)
			{
				status="failure";
			}else {
				hibernateTemplate.delete(emp);
				status="success";
			}
			
		}catch (Exception e) {
		 e.printStackTrace();
		 status="failure";
		}
		
		return status;
	}

	@Override
	public String update(Employee emp) {
		
		 hibernateTemplate.update(emp);
		return "success"; 
	}

}
