package com.mvc.dao;

import com.mvc.dto.Employee;

public interface EmployeeDao {
	    public String add(Employee emp);
	    public Employee search(String eid);
	    public String delete(String eid);
	    public String update(Employee emp);

}
