package com.mvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Columns;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "Employee")
public class Employee {
	@NotBlank(message = "please Enter i'd")
	
	@Column(name = "EMP_ID")
	@Id
	private String eid;

	@NotBlank(message = "Employee name Required")
	@Column(name = "EMP_Name")
	private String ename;

	@Column(name = "EMP_Department")
	@NotBlank(message = "Employee Dep Required")
	private String edep;

	@NotBlank(message = "Employee Des Required")
	@Column(name = "EMP_Designation")
	private String edes;

	@NotNull(message = "Employee salary in Integer Required")
	@Column(name = "EMP_Salary")
	private int esal;

	@NotBlank(message = "Employee current Project Required")
	@Column(name = "EMP_Current_Project")
	private String ecp;

	@NotNull(message = "Employee Experience in Integer Required")
	@Column(name = "EMP_Experience")

	private int ee;

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEdep() {
		return edep;
	}

	public void setEdep(String edep) {
		this.edep = edep;
	}

	public String getEdes() {
		return edes;
	}

	public void setEdes(String edes) {
		this.edes = edes;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public String getEcp() {
		return ecp;
	}

	public void setEcp(String ecp) {
		this.ecp = ecp;
	}

	public int getEe() {
		return ee;
	}

	public void setEe(int ee) {
		this.ee = ee;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", edep=" + edep + ", edes=" + edes + ", esal=" + esal
				+ ", ecp=" + ecp + ", ee=" + ee + "]";
	}

}
