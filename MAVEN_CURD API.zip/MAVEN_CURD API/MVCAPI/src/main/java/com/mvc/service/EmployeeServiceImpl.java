package com.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mvc.dao.EmployeeDao;
import com.mvc.dto.Employee;


@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
   String status="";
   
   @Autowired(required=true)
	private EmployeeDao employeeDao;
//	 public void setEmployeeDao(EmployeeDao employeeDao)
//	    {
//	    	this.employeeDao=employeeDao;
//	    }
	
	@Transactional
	@Override
	public String addEmployee(Employee emp) 
    { 
//		Employee empE=new Employee();
//		empE.setEid(emp.getEid());
//		empE.setEname(emp.getEname());
//		empE.setEdep(emp.getEdep());
//		empE.setEdes(emp.getEdes());
//		empE.setEsal(emp.getEsal());
//		empE.setEcp(emp.getEcp());
//		empE.setEe(emp.getEe());
	    System.out.println("Service Class  : " +emp.getEid() + emp.getEcp() + emp.getEe());
		status=(String)employeeDao.add(emp);
		
		return status;
	} 
   @Transactional
	@Override
	public Employee searchEmployee(String eid) {
		Employee emp=employeeDao.search(eid);
		Employee empE=null;
		if(emp==null)
		{
			empE=null;
		}else
		{
		empE=new Employee();
			empE.setEid(emp.getEid());
			empE.setEname(emp.getEname());
			empE.setEdep(emp.getEdep());
			empE.setEdes(emp.getEdes());
			empE.setEsal(emp.getEsal());
			empE.setEcp(emp.getEcp());
			empE.setEe(emp.getEe());
		}
		
		return empE;
	}
    @Transactional
	@Override
	public String deleteEmployee(String eid) {
		String str=employeeDao.delete(eid);
		return str;
	}
     @Transactional
	@Override
	public String updateEmployee(Employee emp) {
		
         status=(String)employeeDao.update(emp);
    	
    	 
		return status;
	}

}
